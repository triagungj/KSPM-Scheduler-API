<?php

namespace Database\Seeders;

use App\Models\Jabatan;
use Illuminate\Database\Seeder;

class JabatanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Jabatan::create([
            'name' => 'Ketua Umum',
            'jabatan_category_id' => 1,
        ]);

        Jabatan::create([
            'name' => 'Sekretaris Umum',
            'jabatan_category_id' => 1,
        ]);

        Jabatan::create([
            'name' => 'Bendahara Umum',
            'jabatan_category_id' => 1,
        ]);
        Jabatan::create([
            'name' => 'Bursa',
            'jabatan_category_id' => 1,
        ]);

        Jabatan::create([
            'name' => 'Ketua HRD',
            'jabatan_category_id' => 1,
        ]);
        Jabatan::create([
            'name' => 'Staff HRD',
            'jabatan_category_id' => 2,
        ]);

        Jabatan::create([
            'name' => 'Ketua RnD',
            'jabatan_category_id' => 1,
        ]);

        Jabatan::create([
            'name' => 'Staff RnD',
            'jabatan_category_id' => 2,
        ]);
        
        
        Jabatan::create([
            'name' => 'Ketua Trading',
            'jabatan_category_id' => 1,
        ]);
        Jabatan::create([
            'name' => 'Staff Trading',
            'jabatan_category_id' => 2,
        ]);
        
        Jabatan::create([
            'name' => 'Ketua Edukasi',
            'jabatan_category_id' => 1,
        ]);
        Jabatan::create([
            'name' => 'Staff Edukasi',
            'jabatan_category_id' => 2,
        ]);

        Jabatan::create([
            'name' => 'Anggota Magang',
            'jabatan_category_id' => 3,
        ]);
        
        
        
    }
}
